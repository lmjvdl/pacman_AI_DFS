import React, { useState } from 'react';
import { Position } from '../types';

interface ControlsProps {
    onStart: (rows: number, cols: number, agentPosition: Position, foodPosition: Position) => void;
    onGenerateNewMap: () => void;
    map: string[][];
}

const Controls: React.FC<ControlsProps> = ({ onStart, onGenerateNewMap, map }) => {
    const [rows, setRows] = useState(10);
    const [cols, setCols] = useState(10);
    const [agentRow, setAgentRow] = useState(1);
    const [agentCol, setAgentCol] = useState(1);
    const [foodRow, setFoodRow] = useState(8);
    const [foodCol, setFoodCol] = useState(8);
    const [errorMessage, setErrorMessage] = useState<string | null>(null); // وضعیت پیغام خطا

    const handleStart = () => {
        const agentPosition = { x: agentRow, y: agentCol };
        const foodPosition = { x: foodRow, y: foodCol };
    
        if (agentPosition.x === foodPosition.x && agentPosition.y === foodPosition.y) {
            setErrorMessage("Agent and Food positions must be different!");
            return;
        }
    
        if (map[foodPosition.x][foodPosition.y] === 'wall') {
            setErrorMessage("Food can't be placed on a wall!");
            return;
        }
    
        setErrorMessage(null);
        onStart(rows, cols, agentPosition, foodPosition);
    };
    

    return (
        <div className="controls">
            <h2>Set Map Size</h2>
            <div className="form-group input-group">
                <div className="input-container">
                    <input 
                        type="number" 
                        value={rows} 
                        onChange={(e) => setRows(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Number of Rows</label>
                </div>
                <div className="input-container">
                    <input 
                        type="number" 
                        value={cols} 
                        onChange={(e) => setCols(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Number of Columns</label>
                </div>
            </div>

            <h2>Set Agent and Food Position</h2>
            <div className="input-group">
                <div className="input-container">
                    <input 
                        type="number" 
                        value={agentRow} 
                        onChange={(e) => setAgentRow(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Agent Row</label>
                </div>
                <div className="input-container">
                    <input 
                        type="number" 
                        value={agentCol} 
                        onChange={(e) => setAgentCol(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Agent Column</label>
                </div>
                <div className="input-container">
                    <input 
                        type="number" 
                        value={foodRow} 
                        onChange={(e) => setFoodRow(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Food Row</label>
                </div>
                <div className="input-container">
                    <input 
                        type="number" 
                        value={foodCol} 
                        onChange={(e) => setFoodCol(Number(e.target.value))}
                        min={1}
                        className="input-field"
                    />
                    <label>Food Column</label>
                </div>
            </div>
            <div className='buttons'>
                <button onClick={handleStart}>Start new game</button>
                <button className='generate-button' onClick={onGenerateNewMap}>Generate New Map</button>
            </div>
            {errorMessage && <p className="error-message">{errorMessage}</p>} {/* نمایش پیغام خطا */}
        </div>
    );
};
export default Controls;
