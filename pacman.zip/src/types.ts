export type CellType = 'empty' | 'wall' | 'agent' | 'food';

export interface Position {
    x: number;
    y: number;
}

export interface Percept {
    position: Position;
    cellType: CellType;
}
