import { Position, Percept } from '../types';

// آرگومان action را به صورت 'up' | 'down' | 'left' | 'right' تعریف کنید
export function Environment(action: 'up' | 'down' | 'left' | 'right', position: Position, map: string[][]): Percept {
    const newPosition = getNewPosition(action, position);
    const cellType = map[newPosition.x][newPosition.y];

    return {
        position: newPosition,
        cellType: cellType as 'empty' | 'wall' | 'agent' | 'food'  // از نوع مورد نظر استفاده کنید
    };
}

export function getNewPosition(action: 'up' | 'down' | 'left' | 'right', position: Position): Position {
    switch (action) {
        case 'up': return { x: position.x, y: position.y - 1 };
        case 'down': return { x: position.x, y: position.y + 1 };
        case 'left': return { x: position.x - 1, y: position.y };
        case 'right': return { x: position.x + 1, y: position.y };
        default: return position;
    }
}
