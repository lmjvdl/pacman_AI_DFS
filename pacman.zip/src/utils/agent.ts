import { Position } from '../types';
import { getNewPosition } from './environment';

export function dfsFindPath(start: Position, goal: Position, map: string[][]): Position[] | null {
    const stack: Position[] = [start];
    const visited = new Set<string>();
    const path: Position[] = [];

    const isGoalReached = (pos: Position) => pos.x === goal.x && pos.y === goal.y;

    const serialize = (pos: Position) => `${pos.x},${pos.y}`;

    while (stack.length > 0) {
        const current = stack.pop()!;
        path.push(current);
        visited.add(serialize(current));

        if (isGoalReached(current)) return path;

        const neighbors = [
            getNewPosition('up', current),
            getNewPosition('down', current),
            getNewPosition('left', current),
            getNewPosition('right', current),
        ];

        for (const neighbor of neighbors) {
            const isWithinBounds =
                neighbor.x >= 0 && neighbor.x < map.length &&
                neighbor.y >= 0 && neighbor.y < map[0].length;

            if (isWithinBounds && map[neighbor.x][neighbor.y] !== 'wall' && !visited.has(serialize(neighbor))) {
                stack.push(neighbor);
            }
        }
    }
    return null;
}