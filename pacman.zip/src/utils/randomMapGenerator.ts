import { CellType } from '../types';

export function generateRandomMap(rows: number, cols: number): CellType[][] {
    const map: CellType[][] = [];
    for (let i = 0; i < rows; i++) {
        const row: CellType[] = [];
        for (let j = 0; j < cols; j++) {
            // قرار دادن دیوار در دور نقشه
            if (i === 0 || i === rows - 1 || j === 0 || j === cols - 1) {
                row.push('wall');
            } else {
                row.push(Math.random() < 0.2 ? 'wall' : 'empty'); // 20% احتمال دیوار برای خانه‌های داخلی
            }
        }
        map.push(row);
    }
    return map;
}
